export const FLIP_CARD = 'FLIP_CARD'
export const RESTART_GAME = 'RESTART_GAME'
