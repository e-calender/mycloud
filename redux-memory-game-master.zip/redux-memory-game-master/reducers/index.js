import { combineReducers } from 'redux'
import memory from './memory'

const rootReducer = combineReducers({
    memory
});

export default rootReducer;
