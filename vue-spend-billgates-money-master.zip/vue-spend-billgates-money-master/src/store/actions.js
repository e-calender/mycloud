export default({
    buy(context, payload) {context.commit('BUY_SOMTH', payload)},
    sell(context, payload){context.commit('SELL_SOMTH', payload)},
})