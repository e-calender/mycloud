<template>
  <div>
    <Shop />
  </div>
</template>

<script>
import Shop from "../components/Shop.vue";
export default {
  name: "Home",
  components: {
    Shop,
  },
};
</script>

<style lang="scss"></style>
