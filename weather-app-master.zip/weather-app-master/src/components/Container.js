import React from 'react'
import Header from './Header'
function Container() {
  return (
    <div className='header'>
      <Header></Header>  {/* Header bileşeni */}
      <br></br>
    </div>
  )
}

export default Container
