PythonTwitterApi
================

Python da Tweepy kütüphanesi ile twit atmak ve twitleri görmeye yarayan program.

Programın çalıştırmak için önce : https://apps.twitter.com/  adresine giderek bir Twitter Api oluşturmalı.
Daha sonra programda * lar ile bos bırkaılmıs yerlere aldıgınız apileri yazmalısınız.

Daha sonra https://github.com/tweepy/tweepy adresinden tweepy kütüphanesini bilgisayara kurarak programımıza import etmeniz gerekmekte.

Benım yaptıgımdan daha fazla şeyler yapmak istersenizda http://tweepy.readthedocs.org/en/v3.1.0/ incelemenizi tavsite ederim.

Programın Ekran Görüntüsü:

<a href="http://hizliresim.com/oYEy0b"><img src="http://i.hizliresim.com/oYEy0b.png" /></a>
