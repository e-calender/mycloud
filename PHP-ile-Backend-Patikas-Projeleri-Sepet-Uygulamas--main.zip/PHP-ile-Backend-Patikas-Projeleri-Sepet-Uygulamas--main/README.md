[PATİKA](https://app.patika.dev/) dev in Php dersleri çerçevesinde çelıştığımız PHP ile Backend Patikası Projeleri
için verilen Sepet Uygulaması ödevimiz.

[Patika Profilim](https://app.patika.dev/sibgat)

[GitHub Profilim](https://github.com/Sibgatullahsanli)