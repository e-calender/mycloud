import Index from './components/index';

function App() {
  return (
    <div className="App">
      <Index/>
    </div>
  );
}

export default App;
